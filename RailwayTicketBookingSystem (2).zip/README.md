# Railway Ticket Booking System (Java Project)

This is a simple console-based Java project that allows users to book railway tickets.

## Features:
- Book tickets with passenger name, coach type, and mobile number.
- Calculates fare based on coach selection.
- Stores multiple bookings using ArrayList.
- Displays all booked tickets with auto-generated PNR numbers.

## How to Run:
1. Clone the repository or download ZIP.
2. Open in IntelliJ/VS Code.
3. Run `RailwayBookingSystem.java`.

## Requirements:
- Java JDK 8 or higher

## Author:
Insha Khan
